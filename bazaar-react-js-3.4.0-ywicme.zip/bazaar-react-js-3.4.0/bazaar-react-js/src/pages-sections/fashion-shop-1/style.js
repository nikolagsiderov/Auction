// common arrow button for slider
export const arrowButtonStyle = {
  backgroundColor: "white",
  color: "#2B3445"
};