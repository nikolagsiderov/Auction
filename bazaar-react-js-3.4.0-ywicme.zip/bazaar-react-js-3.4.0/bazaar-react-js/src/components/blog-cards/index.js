import BlogCard1 from "./BlogCard1";
import BlogCard2 from "./BlogCard2";
export { BlogCard1, BlogCard2 };